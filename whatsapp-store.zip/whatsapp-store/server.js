require('dotenv').config();

const express = require('express');
const cors    = require('cors');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────

app.use(cors({
  origin: process.env.FRONTEND_URL || '*',
  methods: ['GET', 'POST', 'PATCH'],
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ── Request logger ─────────────────────────────────────────

app.use((req, _res, next) => {
  console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${req.path}`);
  next();
});

// ── Routes ─────────────────────────────────────────────────

app.use('/api/orders', require('./routes/orders'));

// Health check
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', store: process.env.STORE_NAME || 'My Store' });
});

// 404 fallback
app.use((_req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Global error handler
app.use((err, _req, res, _next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// ── Start ──────────────────────────────────────────────────

app.listen(PORT, () => {
  console.log(`\n🚀 Server running at http://localhost:${PORT}`);
  console.log(`📦 Store: ${process.env.STORE_NAME || 'My Store'}`);
  console.log(`💬 WhatsApp number: ${process.env.WA_NUMBER}`);
  console.log(`\nEndpoints:`);
  console.log(`  POST   /api/orders           → Place order + get WA link`);
  console.log(`  GET    /api/orders            → List all orders (admin)`);
  console.log(`  GET    /api/orders/:ref       → Get single order`);
  console.log(`  PATCH  /api/orders/:ref/status → Update order status\n`);
});
