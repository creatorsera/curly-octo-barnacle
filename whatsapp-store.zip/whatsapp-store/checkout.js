// ── Checkout ────────────────────────────────────────────────

const Checkout = (() => {

  // ── Validation ─────────────────────────────────────────────

  function validate(form) {
    const errors = {};

    if (!form.name.trim())
      errors.name = 'Full name is required';

    const phone = form.phone.replace(/[\s\-()]/g, '');
    if (!phone)
      errors.phone = 'Phone number is required';
    else if (!/^0?3\d{9}$/.test(phone))
      errors.phone = 'Enter a valid number (e.g. 0312-3456789)';

    if (!form.address.trim())
      errors.address = 'Delivery address is required';

    if (!form.city.trim())
      errors.city = 'City is required';

    if (!form.payment)
      errors.payment = 'Please select a payment method';

    if (Cart.count() === 0)
      errors.cart = 'Your cart is empty';

    return errors;
  }

  // ── Show field errors ───────────────────────────────────────

  function showErrors(errors) {
    // Clear old errors
    document.querySelectorAll('.error-msg').forEach(el => el.remove());
    document.querySelectorAll('.field-error').forEach(el => el.classList.remove('field-error'));

    Object.entries(errors).forEach(([field, msg]) => {
      const input = document.querySelector(`[name="${field}"]`);
      if (!input) return;
      input.classList.add('field-error');
      const div = document.createElement('div');
      div.className = 'error-msg';
      div.textContent = msg;
      input.parentNode.appendChild(div);
    });

    // Scroll to first error
    const first = document.querySelector('.field-error');
    if (first) first.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  // ── Submit ──────────────────────────────────────────────────

  async function submit() {
    const form = {
      name:    document.querySelector('[name="name"]')?.value || '',
      phone:   document.querySelector('[name="phone"]')?.value || '',
      address: document.querySelector('[name="address"]')?.value || '',
      city:    document.querySelector('[name="city"]')?.value || '',
      payment: document.querySelector('[name="payment"]:checked')?.value || '',
      notes:   document.querySelector('[name="notes"]')?.value || '',
    };

    const errors = validate(form);
    if (Object.keys(errors).length > 0) {
      showErrors(errors);
      return;
    }

    const btn = document.getElementById('wa-submit-btn');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Saving order...';

    try {
      const response = await fetch(`${CONFIG.API_BASE}/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          items: Cart.toLineItems(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Server error');
      }

      // ── Success: order saved, redirect to WhatsApp ──────────
      Cart.clear();
      window.location.href = data.wa_url;

    } catch (err) {
      console.error('Order failed:', err);
      btn.disabled = false;
      btn.innerHTML = waButtonLabel();

      const errorBox = document.getElementById('submit-error');
      if (errorBox) {
        errorBox.textContent = err.message === 'Failed to fetch'
          ? 'Could not reach server. Make sure the backend is running.'
          : `Error: ${err.message}`;
        errorBox.style.display = 'block';
      }
    }
  }

  function waButtonLabel() {
    return `<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
    Order via WhatsApp`;
  }

  return { submit };
})();
