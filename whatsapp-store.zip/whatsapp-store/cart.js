// ── Cart ────────────────────────────────────────────────────
// Persisted to localStorage so it survives page refresh

const Cart = (() => {
  const STORAGE_KEY = 'wa_store_cart';

  let items = load();

  function load() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || {};
    } catch {
      return {};
    }
  }

  function save() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  }

  function add(productId) {
    items[productId] = (items[productId] || 0) + 1;
    save();
    CartUI.update();
  }

  function remove(productId) {
    delete items[productId];
    save();
    CartUI.update();
  }

  function updateQty(productId, qty) {
    if (qty <= 0) {
      remove(productId);
    } else {
      items[productId] = qty;
      save();
      CartUI.update();
    }
  }

  function clear() {
    items = {};
    save();
    CartUI.update();
  }

  function count() {
    return Object.values(items).reduce((a, b) => a + b, 0);
  }

  function total() {
    return Object.entries(items).reduce((sum, [id, qty]) => {
      const product = getProductById(Number(id));
      return product ? sum + product.price * qty : sum;
    }, 0);
  }

  function toLineItems() {
    return Object.entries(items)
      .filter(([id]) => getProductById(Number(id)))
      .map(([id, qty]) => {
        const p = getProductById(Number(id));
        return {
          product_id:   p.id,
          product_name: p.name,
          price:        p.price,
          quantity:     qty,
          emoji:        p.emoji,
        };
      });
  }

  function getQty(productId) {
    return items[productId] || 0;
  }

  return { add, remove, updateQty, clear, count, total, toLineItems, getQty };
})();


// ── Cart UI ─────────────────────────────────────────────────

const CartUI = (() => {
  function update() {
    // Update badge
    const badge = document.getElementById('cart-badge');
    const count = Cart.count();
    if (badge) {
      badge.textContent = count;
      badge.style.display = count > 0 ? 'flex' : 'none';
    }

    // Re-render cart if we're on the cart page
    if (document.getElementById('cart-items')) {
      renderCartPage();
    }

    // Update add-to-cart buttons
    document.querySelectorAll('[data-product-id]').forEach(btn => {
      const id = Number(btn.dataset.productId);
      const qty = Cart.getQty(id);
      if (qty > 0) {
        btn.textContent = `In Cart (${qty})`;
        btn.classList.add('in-cart');
      } else {
        btn.textContent = '+ Add to Cart';
        btn.classList.remove('in-cart');
      }
    });
  }

  return { update };
})();
