# WhatsApp E-Commerce Store

A lightweight e-commerce setup where customers browse products, fill checkout,
and get redirected to WhatsApp Business with their full order pre-filled.
Orders are saved to a local SQLite database before the redirect.

---

## Project Structure

```
whatsapp-store/
├── backend/
│   ├── routes/
│   │   └── orders.js       ← API routes (POST, GET, PATCH)
│   ├── database.js         ← SQLite setup & queries
│   ├── server.js           ← Express entry point
│   ├── .env                ← Your config (WA number, port)
│   └── package.json
└── frontend/
    ├── css/
    │   └── style.css
    ├── js/
    │   ├── data.js         ← Products & helpers
    │   ├── cart.js         ← Cart state (localStorage)
    │   └── checkout.js     ← Form validation & API call
    ├── index.html          ← Shop / product listing
    ├── cart.html           ← Cart review
    └── checkout.html       ← Checkout form + WhatsApp button
```

---

## Setup

### 1. Backend

```bash
cd backend
npm install
```

Edit `.env`:
```
WA_NUMBER=923001234567     # your WhatsApp Business number (no + or spaces)
PORT=3000
FRONTEND_URL=http://localhost:5500
STORE_NAME=My Store
```

Start the server:
```bash
npm run dev      # development (nodemon, auto-restart)
npm start        # production
```

Server runs at: http://localhost:3000

### 2. Frontend

Open `frontend/` with any static server. Easiest options:

**VS Code Live Server** — right-click `index.html` → Open with Live Server  
**Python:**
```bash
cd frontend
python -m http.server 5500
```
**Node:**
```bash
npx serve frontend -p 5500
```

Then open: http://localhost:5500

---

## API Endpoints

| Method | Endpoint                     | Description                          |
|--------|------------------------------|--------------------------------------|
| POST   | /api/orders                  | Save order, returns WhatsApp URL     |
| GET    | /api/orders                  | List all orders (admin use)          |
| GET    | /api/orders/:ref             | Get single order with items          |
| PATCH  | /api/orders/:ref/status      | Update status (confirmed/shipped...) |
| GET    | /api/health                  | Health check                         |

### POST /api/orders — Request body
```json
{
  "name": "Ahmed Khan",
  "phone": "03121234567",
  "address": "House 5, Block B, Gulshan",
  "city": "Karachi",
  "payment": "JazzCash",
  "notes": "Call before delivery",
  "items": [
    { "product_id": 1, "product_name": "Wireless Earbuds", "price": 2500, "quantity": 1 },
    { "product_id": 3, "product_name": "Cotton T-Shirt",   "price": 800,  "quantity": 2 }
  ]
}
```

### Response
```json
{
  "success": true,
  "order_ref": "ORD-A1B2C3D4",
  "wa_url": "https://wa.me/923001234567?text=..."
}
```

---

## Customer Flow

1. Customer browses **index.html** → adds products to cart
2. Cart is saved in **localStorage** (survives page refresh)
3. Goes to **cart.html** → reviews items, adjusts quantities
4. Goes to **checkout.html** → fills name, phone, address, city, payment method
5. Clicks **"Order via WhatsApp"**
6. Frontend calls `POST /api/orders` → order saved to SQLite
7. Backend returns WhatsApp URL with pre-filled message
8. Customer is redirected to WhatsApp → you receive the order and confirm payment

---

## WhatsApp Message Format

```
🛒 *New Order — ORD-A1B2C3D4*

*Customer Details*
Name: Ahmed Khan
Phone: 03121234567
City: Karachi
Address: House 5, Block B, Gulshan

*Order Items*
• Wireless Earbuds x1 = Rs. 2,500
• Cotton T-Shirt x2 = Rs. 1,600

*Total: Rs. 4,100*
Payment: JazzCash
Notes: Call before delivery
```

---

## Order Statuses

Update via `PATCH /api/orders/:ref/status`:
- `pending`    → just placed (default)
- `confirmed`  → you confirmed on WhatsApp
- `shipped`    → dispatched
- `delivered`  → delivered
- `cancelled`  → cancelled

---

## Customising Products

Edit `frontend/js/data.js` to change your products:

```js
const PRODUCTS = [
  { id: 1, name: 'Your Product', price: 1500, emoji: '📦', category: 'Category' },
  // ...
];
```

In production, replace this with a `GET /api/products` fetch from your backend.

---

## Deployment

**Backend:** Deploy to Railway, Render, or a VPS (DigitalOcean)  
**Frontend:** Deploy to Vercel, Netlify, or same VPS  
**Database:** SQLite file lives on the server — back it up regularly

Update `CONFIG.API_BASE` in `frontend/js/data.js` to your live backend URL before deploying.
