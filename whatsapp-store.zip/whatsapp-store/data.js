// ── Config ─────────────────────────────────────────────────
const CONFIG = {
  API_BASE: 'http://localhost:3000/api',
  STORE_NAME: 'My Store',
};

// ── Products ────────────────────────────────────────────────
// In production, fetch these from your backend: GET /api/products
const PRODUCTS = [
  { id: 1,  name: 'Wireless Earbuds',  price: 2500, emoji: '🎧', category: 'Electronics' },
  { id: 2,  name: 'Phone Case',        price: 450,  emoji: '📱', category: 'Electronics' },
  { id: 3,  name: 'Cotton T-Shirt',    price: 800,  emoji: '👕', category: 'Clothing'    },
  { id: 4,  name: 'Running Shoes',     price: 3500, emoji: '👟', category: 'Clothing'    },
  { id: 5,  name: 'Face Serum',        price: 1200, emoji: '🧴', category: 'Beauty'      },
  { id: 6,  name: 'Leather Wallet',    price: 1800, emoji: '👛', category: 'Accessories' },
  { id: 7,  name: 'Water Bottle',      price: 600,  emoji: '🍶', category: 'Home'        },
  { id: 8,  name: 'Notebook Set',      price: 350,  emoji: '📓', category: 'Stationery'  },
];

const PAYMENT_METHODS = [
  'JazzCash',
  'Easypaisa',
  'Bank Transfer',
  'SadaPay',
  'NayaPay',
  'Cash on Delivery',
];

// ── Helpers ─────────────────────────────────────────────────
function fmt(n) {
  return 'Rs. ' + Number(n).toLocaleString('en-PK');
}

function getProductById(id) {
  return PRODUCTS.find(p => p.id === id);
}
