const express = require('express');
const router = express.Router();
const { nanoid } = require('nanoid');
const { saveOrderTx, getOrder, getOrderItems, getAllOrders, updateStatus } = require('../database');

// ── POST /api/orders ────────────────────────────────────────
// Frontend calls this before redirecting to WhatsApp.
// Saves the order, returns the WhatsApp URL.

router.post('/', (req, res) => {
  const { name, phone, address, city, payment, notes, items } = req.body;

  // ── Validate ──────────────────────────────────────────────
  const missing = [];
  if (!name?.trim())    missing.push('name');
  if (!phone?.trim())   missing.push('phone');
  if (!address?.trim()) missing.push('address');
  if (!city?.trim())    missing.push('city');
  if (!payment?.trim()) missing.push('payment');
  if (!items?.length)   missing.push('items');

  if (missing.length) {
    return res.status(400).json({ error: 'Missing fields', fields: missing });
  }

  if (!Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Cart is empty' });
  }

  // ── Calculate total server-side ──────────────────────────
  // Never trust the client total. Recalculate from known prices.
  // In production, fetch prices from DB instead of trusting client.
  const total = items.reduce((sum, item) => {
    if (!item.price || !item.quantity) return sum;
    return sum + (item.price * item.quantity);
  }, 0);

  // ── Generate unique order ref ─────────────────────────────
  const order_ref = `ORD-${nanoid(8).toUpperCase()}`;

  // ── Save to DB ────────────────────────────────────────────
  try {
    saveOrderTx(
      { order_ref, name: name.trim(), phone: phone.trim(), address: address.trim(), city: city.trim(), payment, notes: notes?.trim() || '', total },
      items.map(i => ({
        product_id:   i.product_id,
        product_name: i.product_name,
        price:        i.price,
        quantity:     i.quantity,
      }))
    );
  } catch (err) {
    console.error('DB error:', err);
    return res.status(500).json({ error: 'Failed to save order' });
  }

  // ── Build WhatsApp message ────────────────────────────────
  const fmt = n => `Rs. ${n.toLocaleString('en-PK')}`;

  const itemLines = items
    .map(i => `• ${i.product_name} x${i.quantity} = ${fmt(i.price * i.quantity)}`)
    .join('\n');

  const message = [
    `🛒 *New Order — ${order_ref}*`,
    '',
    `*Customer Details*`,
    `Name: ${name.trim()}`,
    `Phone: ${phone.trim()}`,
    `City: ${city.trim()}`,
    `Address: ${address.trim()}`,
    '',
    `*Order Items*`,
    itemLines,
    '',
    `*Total: ${fmt(total)}*`,
    `Payment: ${payment}`,
    notes?.trim() ? `Notes: ${notes.trim()}` : null,
  ]
    .filter(line => line !== null)
    .join('\n');

  const waUrl = `https://wa.me/${process.env.WA_NUMBER}?text=${encodeURIComponent(message)}`;

  return res.json({ success: true, order_ref, wa_url: waUrl });
});


// ── GET /api/orders ─────────────────────────────────────────
// Admin: list all orders

router.get('/', (req, res) => {
  try {
    const orders = getAllOrders.all();
    res.json({ orders });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});


// ── GET /api/orders/:ref ────────────────────────────────────
// Get single order with its items

router.get('/:ref', (req, res) => {
  const order = getOrder.get(req.params.ref);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  const items = getOrderItems.all(req.params.ref);
  res.json({ order, items });
});


// ── PATCH /api/orders/:ref/status ──────────────────────────
// Admin: update order status (pending → confirmed → shipped → delivered)

router.patch('/:ref/status', (req, res) => {
  const { status } = req.body;
  const allowed = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];
  if (!allowed.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${allowed.join(', ')}` });
  }

  const order = getOrder.get(req.params.ref);
  if (!order) return res.status(404).json({ error: 'Order not found' });

  updateStatus.run(status, req.params.ref);
  res.json({ success: true, order_ref: req.params.ref, status });
});


module.exports = router;
