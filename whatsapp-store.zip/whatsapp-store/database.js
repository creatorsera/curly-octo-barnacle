// Simple JSON file database — works everywhere, no native deps needed.
// For production scale, swap this module for better-sqlite3 or PostgreSQL.
// The rest of the app (routes, server) doesn't need to change.

const fs   = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'store.json');

function load() {
  if (!fs.existsSync(DB_FILE)) return { orders: [], order_items: [] };
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch { return { orders: [], order_items: [] }; }
}

function persist(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function saveOrderTx(orderData, items) {
  const db = load();
  if (db.orders.find(o => o.order_ref === orderData.order_ref))
    throw new Error('Duplicate order_ref');
  db.orders.push({
    ...orderData,
    status:     'pending',
    created_at: new Date().toLocaleString('en-PK', { timeZone: 'Asia/Karachi' }),
  });
  for (const item of items)
    db.order_items.push({ ...item, order_ref: orderData.order_ref });
  persist(db);
}

const getOrder      = { get: (ref) => load().orders.find(o => o.order_ref === ref) || null };
const getOrderItems = { all: (ref) => load().order_items.filter(i => i.order_ref === ref) };
const getAllOrders   = {
  all: () => {
    const db = load();
    return db.orders
      .map(o => ({ ...o, item_count: db.order_items.filter(i => i.order_ref === o.order_ref).length }))
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }
};
const updateStatus = {
  run: (status, ref) => {
    const db = load();
    const o = db.orders.find(o => o.order_ref === ref);
    if (o) o.status = status;
    persist(db);
  }
};

module.exports = { saveOrderTx, getOrder, getOrderItems, getAllOrders, updateStatus };
